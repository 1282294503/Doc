package jp.or.hokuren.dac.view.dac2016;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.RETURNS_SELF;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import jakarta.enterprise.inject.Produces;
import jakarta.inject.Inject;
import java.math.BigDecimal;
import java.util.List;
import jp.or.hokuren.aza.common.def.AZA_SakuzyoKbnCns;
import jp.or.hokuren.aza.database.repository.sql.where.AZA_Where;
import jp.or.hokuren.aza.exception.AZA_ApplicationException;
import jp.or.hokuren.aza.exception.AZA_UniqueConstraintException;
import jp.or.hokuren.aza.session.AZA_LogonInfoDto;
import jp.or.hokuren.dac.def.DAC_MessageNoCns;
import jp.or.hokuren.dac.repository.DAC213_JinkenhiJohoNyuryokuRpo;
import jp.or.hokuren.daa.common.object.DAA_MasterData;
import jp.or.hokuren.daa.common.utils.DAA_DateUtils;
import jp.or.hokuren.daa.common.utils.DAA_FileUtils;
import jp.or.hokuren.daa.common.utils.DAA_MessageUtils;
import jp.or.hokuren.daa.repository.DAA301_JinkenhiRendoJohoHeaderRpo;
import jp.or.hokuren.daa.repository.DAA301_JinkenhiRendoJohoMeisaiRpo;
import jp.or.hokuren.junit.DAA_LogicTestBase;
import jp.or.hokuren.junit.DtoTestUtil;
import org.jboss.weld.junit4.WeldInitiator;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runners.MethodSorters;

/**
 * DAC2016_LaborCostInfoCsvImportLgc の取込ボタンOKメイン処理（okMain）テスト。
 *
 * <p>
 * okMain は csvDtoList を1行ずつループしながら modifyHeaderData（人件費連動情報ヘッダ更新＋添付ファイル
 * アップロード）→ modifyLaborCostInfo（人件費情報入力の登録／更新、必要なら人件費連動情報明細の登録）を
 * 呼び出し、正常終了時は変更前添付ファイルを、例外発生時は変更後添付ファイルを削除する。
 *
 * <p>
 * 検証観点（テスト仕様No.6の確認表を、原本xlsxをopenpyxlで直接読み取って正しく確認した上で設計）:
 * 添付ファイル1/2/3のnull有無、ヘッダRecordEntityの有無と例外発生、5つの入力区分カテゴリ＋非該当、
 * 既存の人件費情報入力RecordEntityの有無（更新／新規)、金額のnull有無、明細RecordEntityの有無、
 * 一意制約例外の発生有無とその後の復活可否、最終的な例外有無、csvDtoListが複数行のケース。
 *
 * <p>
 * Repository検索（find系）はテスト対象の項目コードによらず any() で広く受けるようにし、
 * どのRecordEntityを返す／どの例外を投げるかは 01_input/ScenarioDto.csv の各Y/N列で駆動する。
 * これにより8ケース分のArrangeを個別に書き分けず、共通のexecuteCaseで完結させている。
 *
 * <p>
 * CSV配置: src/test/resources/Data/DAC2016_LaborCostInfoCsvImportLgcTest/test_06_NN/
 * 01_input/DAC2016_LaborCostInfoCsvImportCsvDto.csv … csvDtoList（1件または複数件）
 * 01_input/DAC2016_LaborCostInfoCsvImportUploadedFileDto.csv … 添付ファイルDto
 * 01_input/ScenarioDto.csv … Repository戻り値パターンと期待例外の指定
 * 02_expected/DAC2016_OkMainExpectedDto.csv … 正常終了時の画面操作メッセージ（例外ケースでは省略）
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class DAC2016_LaborCostInfoCsvImportLgcTest06 extends DAA_LogicTestBase {

  private static final String BASE_PATH =
      "src/test/resources/Data/DAC2016_LaborCostInfoCsvImportLgcTest/";

  /** Weld管理下で生成されたテスト対象ロジック。 */
  @Inject
  private DAC2016_LaborCostInfoCsvImportLgc target;

  /** DAA_LogicTestBaseが参照するWeldコンテナ。 */
  @Rule
  public WeldInitiator weld = createWeldInitiator(this, DAC2016_LaborCostInfoCsvImportLgc.class);

  private static final AZA_LogonInfoDto logonInfo = mock(AZA_LogonInfoDto.class);
  private static final DAA_MasterData masterDataUtil = mock(DAA_MasterData.class);
  private static final DAA_FileUtils fileUtils = mock(DAA_FileUtils.class);
  private static final DAA_MessageUtils messageUtils = mock(DAA_MessageUtils.class);
  private static final DAA_DateUtils dateUtils = mock(DAA_DateUtils.class);
  private static final DAA301_JinkenhiRendoJohoHeaderRpo jinkenhiRendoJohoHeaderRpo =
      mock(DAA301_JinkenhiRendoJohoHeaderRpo.class);
  private static final DAC213_JinkenhiJohoNyuryokuRpo jinkenhiJohoNyuryokuRpo =
      mock(DAC213_JinkenhiJohoNyuryokuRpo.class);
  private static final DAA301_JinkenhiRendoJohoMeisaiRpo jinkenhiRendoJohoMeisaiRpo =
      mock(DAA301_JinkenhiRendoJohoMeisaiRpo.class);

  @Override
  protected WeldInitiator getWeld() {
    return weld;
  }

  /** 各ケース実行前にモックのスタブと呼び出し履歴を初期化する。 */
  @Before
  public void setUp() {
    reset(logonInfo, masterDataUtil, fileUtils, messageUtils, dateUtils,
        jinkenhiRendoJohoHeaderRpo, jinkenhiJohoNyuryokuRpo, jinkenhiRendoJohoMeisaiRpo);
  }

  @Produces
  public AZA_LogonInfoDto produceLogonInfo() {
    return logonInfo;
  }

  @Produces
  public DAA_MasterData produceMasterDataUtil() {
    return masterDataUtil;
  }

  @Produces
  public DAA_FileUtils produceFileUtils() {
    return fileUtils;
  }

  @Produces
  public DAA_MessageUtils produceMessageUtils() {
    return messageUtils;
  }

  @Produces
  public DAA_DateUtils produceDateUtils() {
    return dateUtils;
  }

  @Produces
  public DAA301_JinkenhiRendoJohoHeaderRpo produceJinkenhiRendoJohoHeaderRpo() {
    return jinkenhiRendoJohoHeaderRpo;
  }

  @Produces
  public DAC213_JinkenhiJohoNyuryokuRpo produceJinkenhiJohoNyuryokuRpo() {
    return jinkenhiJohoNyuryokuRpo;
  }

  @Produces
  public DAA301_JinkenhiRendoJohoMeisaiRpo produceJinkenhiRendoJohoMeisaiRpo() {
    return jinkenhiRendoJohoMeisaiRpo;
  }

  /** ケース06-01: 給与支給、csvDtoListが複数行（同一データを2回投入）、全項目正常更新。 */
  @Test
  public void case06_01() throws Exception {
    executeCase(1);
  }

  /** ケース06-02: 添付ファイル・ヘッダRecordEntityともにnull。ヘッダ更新処理で例外が発生する。 */
  @Test
  public void case06_02() throws Exception {
    executeCase(2);
  }

  /** ケース06-03: 給与控除、新規登録時に一意制約例外が発生し、復活対象も見つからず例外がスローされる。 */
  @Test
  public void case06_03() throws Exception {
    executeCase(3);
  }

  /** ケース06-04: 会負担健保、対象項目の金額がnullのため登録・更新のどちらも行われない。 */
  @Test
  public void case06_04() throws Exception {
    executeCase(4);
  }

  /** ケース06-05: 会負担年金、既存の人件費情報入力RecordEntityを金額のみ更新する。 */
  @Test
  public void case06_05() throws Exception {
    executeCase(5);
  }

  /** ケース06-06: 預貯金、新規登録で一意制約例外は発生しない。 */
  @Test
  public void case06_06() throws Exception {
    executeCase(6);
  }

  /** ケース06-07: 入力区分が上記以外のため入力項目リストが0件となり、繰り返し処理自体が実行されない。 */
  @Test
  public void case06_07() throws Exception {
    executeCase(7);
  }

  /** ケース06-08: 給与支給、新規登録時に一意制約例外が発生するが、削除済みレコードが見つかり復活更新される。 */
  @Test
  public void case06_08() throws Exception {
    executeCase(8);
  }

  /** ケース番号に対応するCSVを読み込み、okMainの戻り値／例外と主要な依存呼び出しを検証する。 */
  private void executeCase(int patternNo) throws Exception {

    // Data: ケース番号に対応する入力・シナリオ・期待値を読み込む。
    TestCaseData testCase = loadTestCaseData(patternNo);

    // Arrange: 添付ファイルアップロード、各Repository戻り値をシナリオ通りに設定する。
    arrangeCommonDependencies();
    arrangeRepositories(testCase.scenario());

    if (testCase.scenario().hasException()) {
      // Act & Assertions: 例外が期待されるケース。okMain自体が例外を送出することを確認する。
      Throwable thrown = assertThrows(Throwable.class,
          () -> target.okMain(testCase.csvDtoList(), testCase.uploadedFileDto()));
      assertEquals(testCase.scenario().expectedExceptionClass(), thrown.getClass());
      assertMessageUtilsNotCalledForSuccess();
      return;
    }

    // Act: 対象メソッドを実行する。
    String actual = target.okMain(testCase.csvDtoList(), testCase.uploadedFileDto());

    // Assertions: 戻り値と、人件費情報入力Repositoryへの登録/更新有無を検証する。
    assertResponse(testCase, actual);
  }

  // ============================================================
  // Data: CSVパス組み立て、CSV読込、CSV行モデル、1ケース分のデータ集約を担当する。
  // ============================================================

  /** ケース番号から test_06_NN/01_input と 02_expected を読み込み、TestCaseDataへ集約する。 */
  private TestCaseData loadTestCaseData(int patternNo) throws Exception {
    String no = String.format("%02d", patternNo);
    String inputPath = BASE_PATH + "test_06_" + no + "/01_input/";
    String expectedPath = BASE_PATH + "test_06_" + no + "/02_expected/";

    List<DAC2016_LaborCostInfoCsvImportCsvDto> csvDtoList = loadDtoListFromCsv(
        DAC2016_LaborCostInfoCsvImportCsvDto.class,
        inputPath + "DAC2016_LaborCostInfoCsvImportCsvDto.csv");
    DAC2016_LaborCostInfoCsvImportUploadedFileDto uploadedFileDto = DtoTestUtil.loadData(
        DAC2016_LaborCostInfoCsvImportUploadedFileDto.class,
        inputPath + "DAC2016_LaborCostInfoCsvImportUploadedFileDto.csv", 1);
    ScenarioRow scenario = DtoTestUtil.loadData(ScenarioRow.class,
        inputPath + "ScenarioDto.csv", 1);
    ExpectedRow expected = loadIfExists(ExpectedRow.class,
        expectedPath + "DAC2016_OkMainExpectedDto.csv");

    return new TestCaseData(patternNo, csvDtoList, uploadedFileDto, scenario, expected);
  }

  /** 期待値CSVが存在しないケース（例外ケースなど）はnullとして扱う。 */
  private static <T> T loadIfExists(Class<T> type, String csvPath) throws Exception {
    java.io.File file = new java.io.File(csvPath);
    if (!file.isFile()) {
      return null;
    }
    return DtoTestUtil.loadData(type, csvPath, 1);
  }

  /** シナリオCSVの行モデル。Repositoryの戻り値パターンと最終的に期待する例外を表す。 */
  public static class ScenarioRow {
    private String headerFound;
    private String headerFindThrows;
    private String itemRecordFound;
    private String meisaiFound;
    private String insertThrowsUnique;
    private String reviveRecordFound;
    private String expectedException;

    public String getHeaderFound() {
      return headerFound;
    }

    public void setHeaderFound(String headerFound) {
      this.headerFound = headerFound;
    }

    public String getHeaderFindThrows() {
      return headerFindThrows;
    }

    public void setHeaderFindThrows(String headerFindThrows) {
      this.headerFindThrows = headerFindThrows;
    }

    public String getItemRecordFound() {
      return itemRecordFound;
    }

    public void setItemRecordFound(String itemRecordFound) {
      this.itemRecordFound = itemRecordFound;
    }

    public String getMeisaiFound() {
      return meisaiFound;
    }

    public void setMeisaiFound(String meisaiFound) {
      this.meisaiFound = meisaiFound;
    }

    public String getInsertThrowsUnique() {
      return insertThrowsUnique;
    }

    public void setInsertThrowsUnique(String insertThrowsUnique) {
      this.insertThrowsUnique = insertThrowsUnique;
    }

    public String getReviveRecordFound() {
      return reviveRecordFound;
    }

    public void setReviveRecordFound(String reviveRecordFound) {
      this.reviveRecordFound = reviveRecordFound;
    }

    public String getExpectedException() {
      return expectedException;
    }

    public void setExpectedException(String expectedException) {
      this.expectedException = expectedException;
    }

    boolean isHeaderFound() {
      return "Y".equals(headerFound);
    }

    boolean isHeaderFindThrows() {
      return "Y".equals(headerFindThrows);
    }

    boolean isItemRecordFound() {
      return "Y".equals(itemRecordFound);
    }

    boolean isMeisaiFound() {
      return "Y".equals(meisaiFound);
    }

    boolean isInsertThrowsUnique() {
      return "Y".equals(insertThrowsUnique);
    }

    boolean isReviveRecordFound() {
      return "Y".equals(reviveRecordFound);
    }

    boolean hasException() {
      return expectedException != null && !"NONE".equals(expectedException);
    }

    Class<? extends Throwable> expectedExceptionClass() {
      if ("AZA_APPLICATION".equals(expectedException)) {
        return AZA_ApplicationException.class;
      }
      if ("AZA_UNIQUE_CONSTRAINT".equals(expectedException)) {
        return AZA_UniqueConstraintException.class;
      }
      return null;
    }
  }

  /** 正常終了時の期待値行モデル。 */
  public static class ExpectedRow {
    private String screenOperationMessage;

    public String getScreenOperationMessage() {
      return screenOperationMessage;
    }

    public void setScreenOperationMessage(String screenOperationMessage) {
      this.screenOperationMessage = screenOperationMessage;
    }
  }

  /** 1ケース分の入力とシナリオ・期待値を束ねる。 */
  record TestCaseData(int patternNo, List<DAC2016_LaborCostInfoCsvImportCsvDto> csvDtoList,
      DAC2016_LaborCostInfoCsvImportUploadedFileDto uploadedFileDto, ScenarioRow scenario,
      ExpectedRow expected) {
  }

  // ============================================================
  // Arrange: Mockの戻り値設定を担当する。
  // ============================================================

  /** 全ケース共通のスタブ（添付ファイルアップロード、正常完了メッセージ、ログインユーザー）を設定する。 */
  private void arrangeCommonDependencies() {
    when(fileUtils.uploadTempFile(anyString(), any())).thenReturn(BigDecimal.TEN);
    when(messageUtils.getMessage(DAC_MessageNoCns.DAC00310I)).thenReturn("TEST_OK_MAIN_MESSAGE");
    when(logonInfo.getUserId()).thenReturn("TESTUSER");
  }

  /**
   * シナリオCSVの内容に従い、人件費連動情報ヘッダ／人件費情報入力／人件費連動情報明細の各Repositoryの
   * 戻り値・例外をスタブする。項目コード自体には依存しないよう any() で広く受ける。
   */
  private void arrangeRepositories(ScenarioRow scenario) {
    AZA_Where mockWhere = mock(AZA_Where.class, RETURNS_SELF);
    when(jinkenhiRendoJohoHeaderRpo.where(any())).thenReturn(mockWhere);

    if (scenario.isHeaderFindThrows()) {
      when(jinkenhiRendoJohoHeaderRpo.find(any(AZA_Where.class)))
          .thenThrow(AZA_ApplicationException.class);
      return;
    }

    if (scenario.isHeaderFound()) {
      DAA301_JinkenhiRendoJohoHeaderRpo.RecordEntity headerRecord =
          mock(DAA301_JinkenhiRendoJohoHeaderRpo.RecordEntity.class);
      when(headerRecord.getHaitaCnt()).thenReturn(1);
      when(jinkenhiRendoJohoHeaderRpo.find(any(AZA_Where.class))).thenReturn(headerRecord);
    } else {
      when(jinkenhiRendoJohoHeaderRpo.find(any(AZA_Where.class))).thenReturn(null);
    }

    // 人件費情報入力Repository: 更新パス用の既存RecordEntity。
    if (scenario.isItemRecordFound()) {
      DAC213_JinkenhiJohoNyuryokuRpo.RecordEntity itemRecord =
          mock(DAC213_JinkenhiJohoNyuryokuRpo.RecordEntity.class);
      when(itemRecord.getHaitaCnt()).thenReturn(1);
      when(jinkenhiJohoNyuryokuRpo.find(any(), any(), any(), any(), any(), any(), any(), any(),
          any(), eq(AZA_SakuzyoKbnCns.MISAKUZYO))).thenReturn(itemRecord);
    } else {
      when(jinkenhiJohoNyuryokuRpo.find(any(), any(), any(), any(), any(), any(), any(), any(),
          any(), eq(AZA_SakuzyoKbnCns.MISAKUZYO))).thenReturn(null);
    }

    // 人件費連動情報明細Repository: 新規登録パスで既存の明細が見つかるかどうか。
    if (scenario.isMeisaiFound()) {
      DAA301_JinkenhiRendoJohoMeisaiRpo.RecordEntity meisaiRecord =
          mock(DAA301_JinkenhiRendoJohoMeisaiRpo.RecordEntity.class);
      when(jinkenhiRendoJohoMeisaiRpo.find(any(), any(), any(), any(), any(), any(), any(), any(),
          any(), any())).thenReturn(meisaiRecord);
    } else {
      when(jinkenhiRendoJohoMeisaiRpo.find(any(), any(), any(), any(), any(), any(), any(), any(),
          any(), any())).thenReturn(null);
    }

    // 一意制約例外パス: insert時にAZA_UniqueConstraintExceptionを投げるか、
    // 投げる場合は削除済みレコードを再検索した際の復活対象有無を分岐させる。
    if (scenario.isInsertThrowsUnique()) {
      when(jinkenhiJohoNyuryokuRpo.insert(any())).thenThrow(AZA_UniqueConstraintException.class);
      if (scenario.isReviveRecordFound()) {
        DAC213_JinkenhiJohoNyuryokuRpo.RecordEntity reviveRecord =
            mock(DAC213_JinkenhiJohoNyuryokuRpo.RecordEntity.class);
        when(reviveRecord.getHaitaCnt()).thenReturn(1);
        when(jinkenhiJohoNyuryokuRpo.find(any(), any(), any(), any(), any(), any(), any(), any(),
            any(), eq(AZA_SakuzyoKbnCns.SAKUZYOZUMI))).thenReturn(reviveRecord);
      } else {
        when(jinkenhiJohoNyuryokuRpo.find(any(), any(), any(), any(), any(), any(), any(), any(),
            any(), eq(AZA_SakuzyoKbnCns.SAKUZYOZUMI))).thenReturn(null);
      }
    }
  }

  // ============================================================
  // Assertions: 戻り値とMockito呼び出し引数の検証を担当する。
  // ============================================================

  /** okMainの戻り値が期待値CSVと一致することを検証する。 */
  private void assertResponse(TestCaseData testCase, String actual) {
    assertEquals(testCase.expected().getScreenOperationMessage(), actual);
  }

  /** 例外ケースでは、正常完了メッセージ取得（messageUtils.getMessage）が呼ばれないことを検証する。 */
  private void assertMessageUtilsNotCalledForSuccess() {
    verify(messageUtils, never()).getMessage(DAC_MessageNoCns.DAC00310I);
  }
}
