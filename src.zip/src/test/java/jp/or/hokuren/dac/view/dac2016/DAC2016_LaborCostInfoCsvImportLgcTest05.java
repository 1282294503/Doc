package jp.or.hokuren.dac.view.dac2016;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import jakarta.enterprise.inject.Produces;
import jakarta.inject.Inject;
import jp.or.hokuren.aza.session.AZA_LogonInfoDto;
import jp.or.hokuren.dac.def.DAC_MessageNoCns;
import jp.or.hokuren.dac.repository.DAC213_JinkenhiJohoNyuryokuRpo;
import jp.or.hokuren.daa.common.object.DAA_MasterData;
import jp.or.hokuren.daa.common.utils.DAA_DateUtils;
import jp.or.hokuren.daa.common.utils.DAA_FileUtils;
import jp.or.hokuren.daa.common.utils.DAA_MessageUtils;
import jp.or.hokuren.daa.repository.DAA301_JinkenhiRendoJohoHeaderRpo;
import jp.or.hokuren.daa.repository.DAA301_JinkenhiRendoJohoMeisaiRpo;
import jp.or.hokuren.junit.DAA_LogicTestBase;
import jp.or.hokuren.junit.DtoTestUtil;
import org.jboss.weld.junit4.WeldInitiator;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runners.MethodSorters;

/**
 * DAC2016_LaborCostInfoCsvImportLgc の初期処理メイン処理（initMain）テスト。
 *
 * <p>
 * 対象メソッドは、messageUtils#メッセージ取得処理の戻り値をそのまま画面操作メッセージとして
 * 返却するだけの処理であるため、検証観点は次の2点のみとする。
 * 1. messageUtils.getMessage が定数.メッセージ管理番号.DAC00189I を引数に呼ばれること
 * 2. initMain の戻り値が、messageUtils.getMessage のモック戻り値とそのまま一致すること
 *
 * <p>
 * 例外系は存在しないため、正常系1パターン（case05_01）のみを扱う。
 * CSV配置: src/test/resources/Data/DAC2016_LaborCostInfoCsvImportLgcTest/test_05_01/
 * 01_input/DAC2016_InitMainMessageUtilsReturnDto.csv … messageUtils.getMessage のモック戻り値
 * 02_expected/DAC2016_InitMainExpectedDto.csv … initMain の戻り値期待値
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class DAC2016_LaborCostInfoCsvImportLgcTest05 extends DAA_LogicTestBase {

  /** Weld管理下で生成されたテスト対象ロジック。 */
  @Inject
  private DAC2016_LaborCostInfoCsvImportLgc target;

  /** DAA_LogicTestBaseが参照するWeldコンテナ。 */
  @Rule
  public WeldInitiator weld = createWeldInitiator(this, DAC2016_LaborCostInfoCsvImportLgc.class);

  // initMainが利用する依存部品。CDI解決のため対象の@Inject全項目分を@Producesする。
  // このテスト観点で実際にスタブするのはmessageUtilsのみで、他は未使用依存として供給する。
  private static final AZA_LogonInfoDto logonInfo = mock(AZA_LogonInfoDto.class);
  private static final DAA_MasterData masterDataUtil = mock(DAA_MasterData.class);
  private static final DAA_FileUtils fileUtils = mock(DAA_FileUtils.class);
  private static final DAA_MessageUtils messageUtils = mock(DAA_MessageUtils.class);
  private static final DAA_DateUtils dateUtils = mock(DAA_DateUtils.class);
  private static final DAA301_JinkenhiRendoJohoHeaderRpo jinkenhiRendoJohoHeaderRpo =
      mock(DAA301_JinkenhiRendoJohoHeaderRpo.class);
  private static final DAC213_JinkenhiJohoNyuryokuRpo jinkenhiJohoNyuryokuRpo =
      mock(DAC213_JinkenhiJohoNyuryokuRpo.class);
  private static final DAA301_JinkenhiRendoJohoMeisaiRpo jinkenhiRendoJohoMeisaiRpo =
      mock(DAA301_JinkenhiRendoJohoMeisaiRpo.class);

  /** 基底クラスへ本クラスのWeldInitiatorを渡す。 */
  @Override
  protected WeldInitiator getWeld() {
    return weld;
  }

  /** 各ケース実行前にモックのスタブと呼び出し履歴を初期化する。 */
  @Before
  public void setUp() {
    reset(logonInfo, masterDataUtil, fileUtils, messageUtils, dateUtils,
        jinkenhiRendoJohoHeaderRpo, jinkenhiJohoNyuryokuRpo, jinkenhiRendoJohoMeisaiRpo);
  }

  /** CDIへログオン情報モックを供給する。 */
  @Produces
  public AZA_LogonInfoDto produceLogonInfo() {
    return logonInfo;
  }

  /** CDIへマスタデータ取得ユーティリティモックを供給する。 */
  @Produces
  public DAA_MasterData produceMasterDataUtil() {
    return masterDataUtil;
  }

  /** CDIへファイルユーティリティモックを供給する。 */
  @Produces
  public DAA_FileUtils produceFileUtils() {
    return fileUtils;
  }

  /** CDIへメッセージ取得ユーティリティモックを供給する。 */
  @Produces
  public DAA_MessageUtils produceMessageUtils() {
    return messageUtils;
  }

  /** CDIへ日時ユーティリティモックを供給する。 */
  @Produces
  public DAA_DateUtils produceDateUtils() {
    return dateUtils;
  }

  /** CDIへ人件費連動情報ヘッダRepositoryモックを供給する。 */
  @Produces
  public DAA301_JinkenhiRendoJohoHeaderRpo produceJinkenhiRendoJohoHeaderRpo() {
    return jinkenhiRendoJohoHeaderRpo;
  }

  /** CDIへ人件費情報入力Repositoryモックを供給する。 */
  @Produces
  public DAC213_JinkenhiJohoNyuryokuRpo produceJinkenhiJohoNyuryokuRpo() {
    return jinkenhiJohoNyuryokuRpo;
  }

  /** CDIへ人件費連動情報明細Repositoryモックを供給する。 */
  @Produces
  public DAA301_JinkenhiRendoJohoMeisaiRpo produceJinkenhiRendoJohoMeisaiRpo() {
    return jinkenhiRendoJohoMeisaiRpo;
  }

  /** ケース05-01: messageUtilsのモック戻り値がそのまま画面操作メッセージとして返却されることを確認する。 */
  @Test
  public void case05_01() throws Exception {
    executeCase(1);
  }

  /** ケース番号に対応するCSVを読み込み、initMainの戻り値と依存呼び出しを検証する。 */
  private void executeCase(int patternNo) throws Exception {

    // Data: ケース番号に対応するモック戻り値と期待値を読み込む。
    TestCaseData testCase = Data.load(patternNo);

    // Arrange: messageUtils.getMessage の戻り値をケースごとに設定する。
    Arrange.arrangeMessageUtils(testCase, messageUtils);

    // Act: 対象メソッドを実行する。
    String actual = target.initMain();

    // Assertions: 戻り値と、messageUtilsへ渡した引数を検証する。
    Assertions.assertResponse(testCase, actual);
    Assertions.assertMessageUtilsArgument();
  }

  // ============================================================
  // Data: CSVパス組み立て、CSV読込、CSV行モデル、1ケース分のデータ集約を担当する。
  // ============================================================

  /** CSV行モデル。画面操作メッセージ1項目のみを持つため、モック戻り値・期待値の両方で共用する。 */
  public static class MessageRow {
    private String screenOperationMessage;

    public String getScreenOperationMessage() {
      return screenOperationMessage;
    }

    public void setScreenOperationMessage(String screenOperationMessage) {
      this.screenOperationMessage = screenOperationMessage;
    }
  }

  /** 1ケース分の入力（モック戻り値）と期待値を束ねる。 */
  record TestCaseData(int patternNo, MessageRow mockMessage, MessageRow expected) {
  }

  /** CSVパスの組み立てとCSV読込を担当するData helper。 */
  private static final class Data {

    private static final String BASE_PATH =
        "src/test/resources/Data/DAC2016_LaborCostInfoCsvImportLgcTest/";

    /** ケース番号から test_05_NN/01_input と 02_expected を読み込み、TestCaseDataへ集約する。 */
    static TestCaseData load(int patternNo) throws Exception {
      String no = String.format("%02d", patternNo);
      String inputPath = BASE_PATH + "test_05_" + no + "/01_input/";
      String expectedPath = BASE_PATH + "test_05_" + no + "/02_expected/";

      MessageRow mockMessage = DtoTestUtil.loadData(MessageRow.class,
          inputPath + "DAC2016_InitMainMessageUtilsReturnDto.csv", 1);
      MessageRow expected = DtoTestUtil.loadData(MessageRow.class,
          expectedPath + "DAC2016_InitMainExpectedDto.csv", 1);

      return new TestCaseData(patternNo, mockMessage, expected);
    }
  }

  // ============================================================
  // Arrange: Mockの戻り値設定を担当する。
  // ============================================================

  private static final class Arrange {

    /** messageUtils.getMessage(DAC00189I) の戻り値をCSV値から設定する。 */
    static void arrangeMessageUtils(TestCaseData testCase, DAA_MessageUtils messageUtils) {
      when(messageUtils.getMessage(DAC_MessageNoCns.DAC00189I))
          .thenReturn(testCase.mockMessage().getScreenOperationMessage());
    }
  }

  // ============================================================
  // Assertions: 戻り値とMockito呼び出し引数の検証を担当する。
  // ============================================================

  private static final class Assertions {

    /** initMain の戻り値が期待値CSVと一致することを検証する。 */
    static void assertResponse(TestCaseData testCase, String actual) {
      assertEquals(testCase.expected().getScreenOperationMessage(), actual);
    }

    /** messageUtils.getMessage が定数.メッセージ管理番号.DAC00189I を引数に1回だけ呼ばれたことを検証する。 */
    static void assertMessageUtilsArgument() {
      verify(messageUtils, times(1)).getMessage(DAC_MessageNoCns.DAC00189I);
    }
  }
}
