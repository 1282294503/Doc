package jp.or.hokuren.dac.view.dac2016;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import jakarta.enterprise.inject.Produces;
import jakarta.inject.Inject;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import jp.or.hokuren.aza.session.AZA_LogonInfoDto;
import jp.or.hokuren.dac.def.DAC_MessageNoCns;
import jp.or.hokuren.dac.repository.DAC213_JinkenhiJohoNyuryokuRpo;
import jp.or.hokuren.daa.def.DAA_AccountCdCns;
import jp.or.hokuren.daa.common.object.DAA_CodeJohoDto;
import jp.or.hokuren.daa.common.object.DAA_GyoshuJohoDto;
import jp.or.hokuren.daa.common.object.DAA_MasterData;
import jp.or.hokuren.daa.common.object.DAA_SoshikiGyoshuJohoDto;
import jp.or.hokuren.daa.common.object.DAA_SoshikiJohoDto;
import jp.or.hokuren.daa.common.utils.DAA_DateUtils;
import jp.or.hokuren.daa.common.utils.DAA_FileUtils;
import jp.or.hokuren.daa.common.utils.DAA_MessageUtils;
import jp.or.hokuren.daa.exception.BusinessValidationException;
import jp.or.hokuren.daa.repository.DAA301_JinkenhiRendoJohoHeaderRpo;
import jp.or.hokuren.daa.repository.DAA301_JinkenhiRendoJohoMeisaiRpo;
import jp.or.hokuren.junit.DAA_LogicTestBase;
import jp.or.hokuren.junit.DtoTestUtil;
import org.jboss.weld.junit4.WeldInitiator;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runners.MethodSorters;

/**
 * DAC2016_LaborCostInfoCsvImportLgc の取込ボタンメイン処理（importCsvMain）テスト。
 *
 * <p>
 * importCsvMain は validateSingleInput → validateRelatedInput → fileUtils#uploadCsv →
 * validateSingleCsv → validateRelatedCsv の順に実行し、途中でエラーが1件でもあれば
 * BusinessValidationExceptionをスローする。本クラスは、テスト仕様No.7の確認表を
 * openpyxlで原本xlsxから直接読み取って確定させた12パターンをそのまま実装したものである。
 *
 * <p>
 * 検証観点: CSVファイル名／添付ファイル名の桁数チェック、添付ファイル合計サイズチェック、
 * csvDtoリストの件数チェック、給与個所／業種／所属マスタの存在チェック、
 * 人件費連動情報明細・ヘッダの存在チェックと承認状況チェック、業種／所属の組み合わせチェック。
 *
 * <p>
 * fileUtils.uploadCsv はMockでcsvDtoListを直接返すようにし、CSVパース処理そのものは
 * テスト対象外とする。添付ファイルの合計サイズは、CSVで読み込んだUploadedFileの代わりに
 * Arrangeでサイズ指定済みのモックUploadedFileへ差し替えることで制御する。
 *
 * <p>
 * CSV配置: src/test/resources/Data/DAC2016_LaborCostInfoCsvImportLgcTest/test_07_NN/
 * 01_input/DAC2016_LaborCostInfoCsvImportUploadedFileDto.csv … 添付ファイルDto（ファイル名の桁数用）
 * 01_input/DAC2016_LaborCostInfoCsvImportCsvDto.csv … uploadCsvの戻り値として使うcsvDtoリスト
 * 01_input/ScenarioDto.csv … マスタ／Repository戻り値パターンとファイルサイズ、期待結果の指定
 * 02_expected/DAC2016_ImportCsvMainExpectedDto.csv … 正常終了時の戻り値件数（例外ケースでは省略）
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class DAC2016_LaborCostInfoCsvImportLgcTest07 extends DAA_LogicTestBase {

  private static final String BASE_PATH =
      "src/test/resources/Data/DAC2016_LaborCostInfoCsvImportLgcTest/";

  /** 添付ファイル上限サイズ（50メガバイト、エラーメッセージ文言に基づく）。 */
  private static final long TENPU_FILE_MAX_SIZE = 50L * 1024 * 1024;

  /** Weld管理下で生成されたテスト対象ロジック。 */
  @Inject
  private DAC2016_LaborCostInfoCsvImportLgc target;

  /** DAA_LogicTestBaseが参照するWeldコンテナ。 */
  @Rule
  public WeldInitiator weld = createWeldInitiator(this, DAC2016_LaborCostInfoCsvImportLgc.class);

  private static final AZA_LogonInfoDto logonInfo = mock(AZA_LogonInfoDto.class);
  private static final DAA_MasterData masterDataUtil = mock(DAA_MasterData.class);
  private static final DAA_FileUtils fileUtils = mock(DAA_FileUtils.class);
  private static final DAA_MessageUtils messageUtils = mock(DAA_MessageUtils.class);
  private static final DAA_DateUtils dateUtils = mock(DAA_DateUtils.class);
  private static final DAA301_JinkenhiRendoJohoHeaderRpo jinkenhiRendoJohoHeaderRpo =
      mock(DAA301_JinkenhiRendoJohoHeaderRpo.class);
  private static final DAC213_JinkenhiJohoNyuryokuRpo jinkenhiJohoNyuryokuRpo =
      mock(DAC213_JinkenhiJohoNyuryokuRpo.class);
  private static final DAA301_JinkenhiRendoJohoMeisaiRpo jinkenhiRendoJohoMeisaiRpo =
      mock(DAA301_JinkenhiRendoJohoMeisaiRpo.class);

  @Override
  protected WeldInitiator getWeld() {
    return weld;
  }

  /** 各ケース実行前にモックのスタブと呼び出し履歴を初期化する。 */
  @Before
  public void setUp() {
    reset(logonInfo, masterDataUtil, fileUtils, messageUtils, dateUtils,
        jinkenhiRendoJohoHeaderRpo, jinkenhiJohoNyuryokuRpo, jinkenhiRendoJohoMeisaiRpo);
    when(dateUtils.convertIntegerToLocalDate(any())).thenReturn(LocalDate.of(2026, 4, 1));
  }

  @Produces
  public AZA_LogonInfoDto produceLogonInfo() {
    return logonInfo;
  }

  @Produces
  public DAA_MasterData produceMasterDataUtil() {
    return masterDataUtil;
  }

  @Produces
  public DAA_FileUtils produceFileUtils() {
    return fileUtils;
  }

  @Produces
  public DAA_MessageUtils produceMessageUtils() {
    return messageUtils;
  }

  @Produces
  public DAA_DateUtils produceDateUtils() {
    return dateUtils;
  }

  @Produces
  public DAA301_JinkenhiRendoJohoHeaderRpo produceJinkenhiRendoJohoHeaderRpo() {
    return jinkenhiRendoJohoHeaderRpo;
  }

  @Produces
  public DAC213_JinkenhiJohoNyuryokuRpo produceJinkenhiJohoNyuryokuRpo() {
    return jinkenhiJohoNyuryokuRpo;
  }

  @Produces
  public DAA301_JinkenhiRendoJohoMeisaiRpo produceJinkenhiRendoJohoMeisaiRpo() {
    return jinkenhiRendoJohoMeisaiRpo;
  }

  /** ケース07-01: 全項目正常。csvDtoListは複数件で、両方とも全チェックを通過して返却される。 */
  @Test
  public void case07_01() throws Exception {
    executeCase(1);
  }

  /** ケース07-02: CSVファイル名が65桁以上 → DAC00011E。 */
  @Test
  public void case07_02() throws Exception {
    executeCase(2);
  }

  /** ケース07-03: 添付ファイルなし、csvDtoListが0件 → DAC00068E。 */
  @Test
  public void case07_03() throws Exception {
    executeCase(3);
  }

  /** ケース07-04: 添付ファイル1〜3すべてのファイル名が65桁以上 → DAC00011E。 */
  @Test
  public void case07_04() throws Exception {
    executeCase(4);
  }

  /** ケース07-05: 添付ファイル1のみ存在し、合計サイズが上限を超える → DAC00280E。 */
  @Test
  public void case07_05() throws Exception {
    executeCase(5);
  }

  /** ケース07-06: 給与個所／業種／所属マスタがすべてnull、ヘッダ・業種組み合わせもnull → DAC00307E。 */
  @Test
  public void case07_06() throws Exception {
    executeCase(6);
  }

  /** ケース07-07: 添付ファイル3のみ存在。全チェック正常で正常終了する。 */
  @Test
  public void case07_07() throws Exception {
    executeCase(7);
  }

  /** ケース07-08: 人件費連動情報明細RecordEntityリスト自体がnull → DAC00307E。 */
  @Test
  public void case07_08() throws Exception {
    executeCase(8);
  }

  /** ケース07-09: 人件費連動情報明細RecordEntityリストが0件 → DAC00307E。 */
  @Test
  public void case07_09() throws Exception {
    executeCase(9);
  }

  /** ケース07-10: ヘッダRecordEntityの承認状況が「差戻」（許容値）。正常終了する。 */
  @Test
  public void case07_10() throws Exception {
    executeCase(10);
  }

  /** ケース07-11: ヘッダRecordEntityの承認状況が「下書保存」（許容値）。正常終了する。 */
  @Test
  public void case07_11() throws Exception {
    executeCase(11);
  }

  /** ケース07-12: ヘッダRecordEntityの承認状況が許容値以外 → DAC00308E。 */
  @Test
  public void case07_12() throws Exception {
    executeCase(12);
  }

  /** ケース番号に対応するCSVを読み込み、importCsvMainの戻り値／例外を検証する。 */
  private void executeCase(int patternNo) throws Exception {

    // Data: ケース番号に対応する入力・シナリオ・期待値を読み込む。
    TestCaseData testCase = loadTestCaseData(patternNo);

    // Arrange: uploadCsvの戻り値、マスタ／各Repositoryの戻り値をシナリオ通りに設定する。
    arrangeFileUpload(testCase);
    arrangeMasterData(testCase.scenario());
    arrangeRepositories(testCase.scenario());

    if (testCase.scenario().hasBusinessError()) {
      // Act & Assertions: 画面項目チェックまたはCSVデータチェックでエラーになるケース。
      BusinessValidationException ex = org.junit.Assert.assertThrows(
          BusinessValidationException.class,
          () -> target.importCsvMain(testCase.uploadedFileDto()));
      assertEquals(testCase.scenario().getExpectedErrorMessageId(),
          ex.getErrors().get(0).getMessageId());
      return;
    }

    // Act: 対象メソッドを実行する。
    List<DAC2016_LaborCostInfoCsvImportCsvDto> actual =
        target.importCsvMain(testCase.uploadedFileDto());

    // Assertions: 戻り値の件数を検証する。
    assertEquals(testCase.expected().getExpectedCount().intValue(), actual.size());
  }

  // ============================================================
  // Data: CSVパス組み立て、CSV読込、CSV行モデル、1ケース分のデータ集約を担当する。
  // ============================================================

  private TestCaseData loadTestCaseData(int patternNo) throws Exception {
    String no = String.format("%02d", patternNo);
    String inputPath = BASE_PATH + "test_07_" + no + "/01_input/";
    String expectedPath = BASE_PATH + "test_07_" + no + "/02_expected/";

    DAC2016_LaborCostInfoCsvImportUploadedFileDto uploadedFileDto = DtoTestUtil.loadData(
        DAC2016_LaborCostInfoCsvImportUploadedFileDto.class,
        inputPath + "DAC2016_LaborCostInfoCsvImportUploadedFileDto.csv", 1);
    List<DAC2016_LaborCostInfoCsvImportCsvDto> uploadedCsvDtoList = loadDtoListFromCsv(
        DAC2016_LaborCostInfoCsvImportCsvDto.class,
        inputPath + "DAC2016_LaborCostInfoCsvImportCsvDto.csv");
    ScenarioRow scenario = DtoTestUtil.loadData(ScenarioRow.class,
        inputPath + "ScenarioDto.csv", 1);
    ExpectedRow expected = loadIfExists(ExpectedRow.class,
        expectedPath + "DAC2016_ImportCsvMainExpectedDto.csv");

    return new TestCaseData(patternNo, uploadedFileDto, uploadedCsvDtoList, scenario, expected);
  }

  private static <T> T loadIfExists(Class<T> type, String csvPath) throws Exception {
    java.io.File file = new java.io.File(csvPath);
    if (!file.isFile()) {
      return null;
    }
    return DtoTestUtil.loadData(type, csvPath, 1);
  }

  /** シナリオCSVの行モデル。マスタ／Repository戻り値パターン、ファイルサイズ、期待結果を表す。 */
  public static class ScenarioRow {
    private String tenpuFile1SizeBytes;
    private String tenpuFile2SizeBytes;
    private String tenpuFile3SizeBytes;
    private String kyuyoKashoFound;
    private String gyoshuFound;
    private String shozokuFound;
    private String meisaiListState;
    private String headerState;
    private String gyoshuKumiawaseFound;
    private String expectedErrorMessageId;

    public String getTenpuFile1SizeBytes() {
      return tenpuFile1SizeBytes;
    }

    public void setTenpuFile1SizeBytes(String tenpuFile1SizeBytes) {
      this.tenpuFile1SizeBytes = tenpuFile1SizeBytes;
    }

    public String getTenpuFile2SizeBytes() {
      return tenpuFile2SizeBytes;
    }

    public void setTenpuFile2SizeBytes(String tenpuFile2SizeBytes) {
      this.tenpuFile2SizeBytes = tenpuFile2SizeBytes;
    }

    public String getTenpuFile3SizeBytes() {
      return tenpuFile3SizeBytes;
    }

    public void setTenpuFile3SizeBytes(String tenpuFile3SizeBytes) {
      this.tenpuFile3SizeBytes = tenpuFile3SizeBytes;
    }

    public String getKyuyoKashoFound() {
      return kyuyoKashoFound;
    }

    public void setKyuyoKashoFound(String kyuyoKashoFound) {
      this.kyuyoKashoFound = kyuyoKashoFound;
    }

    public String getGyoshuFound() {
      return gyoshuFound;
    }

    public void setGyoshuFound(String gyoshuFound) {
      this.gyoshuFound = gyoshuFound;
    }

    public String getShozokuFound() {
      return shozokuFound;
    }

    public void setShozokuFound(String shozokuFound) {
      this.shozokuFound = shozokuFound;
    }

    public String getMeisaiListState() {
      return meisaiListState;
    }

    public void setMeisaiListState(String meisaiListState) {
      this.meisaiListState = meisaiListState;
    }

    public String getHeaderState() {
      return headerState;
    }

    public void setHeaderState(String headerState) {
      this.headerState = headerState;
    }

    public String getGyoshuKumiawaseFound() {
      return gyoshuKumiawaseFound;
    }

    public void setGyoshuKumiawaseFound(String gyoshuKumiawaseFound) {
      this.gyoshuKumiawaseFound = gyoshuKumiawaseFound;
    }

    public String getExpectedErrorMessageId() {
      return expectedErrorMessageId;
    }

    public void setExpectedErrorMessageId(String expectedErrorMessageId) {
      this.expectedErrorMessageId = expectedErrorMessageId;
    }

    boolean hasBusinessError() {
      return expectedErrorMessageId != null && !expectedErrorMessageId.isBlank();
    }

    long tenpuFile1Size() {
      return tenpuFile1SizeBytes == null ? 0L : Long.parseLong(tenpuFile1SizeBytes);
    }

    long tenpuFile2Size() {
      return tenpuFile2SizeBytes == null ? 0L : Long.parseLong(tenpuFile2SizeBytes);
    }

    long tenpuFile3Size() {
      return tenpuFile3SizeBytes == null ? 0L : Long.parseLong(tenpuFile3SizeBytes);
    }

    boolean isKyuyoKashoFound() {
      return "Y".equals(kyuyoKashoFound);
    }

    boolean isGyoshuFound() {
      return "Y".equals(gyoshuFound);
    }

    boolean isShozokuFound() {
      return "Y".equals(shozokuFound);
    }

    boolean isGyoshuKumiawaseFound() {
      return "Y".equals(gyoshuKumiawaseFound);
    }
  }

  /** 正常終了時の期待値行モデル。 */
  public static class ExpectedRow {
    private Integer expectedCount;

    public Integer getExpectedCount() {
      return expectedCount;
    }

    public void setExpectedCount(Integer expectedCount) {
      this.expectedCount = expectedCount;
    }
  }

  /** 1ケース分の入力とシナリオ・期待値を束ねる。 */
  record TestCaseData(int patternNo,
      DAC2016_LaborCostInfoCsvImportUploadedFileDto uploadedFileDto,
      List<DAC2016_LaborCostInfoCsvImportCsvDto> uploadedCsvDtoList, ScenarioRow scenario,
      ExpectedRow expected) {
  }

  // ============================================================
  // Arrange: Mockの戻り値設定を担当する。
  // ============================================================

  /**
   * fileUtils#CSVアップロード処理の戻り値をuploadedCsvDtoListに固定し、添付ファイルのサイズを
   * シナリオCSV指定のバイト数へ差し替える（CSV駆動のUploadedFileスタブは桁数チェック用の
   * ファイル名しか制御できないため、サイズはArrangeでモックへ明示的に上書きする）。
   */
  private void arrangeFileUpload(TestCaseData testCase) {
    when(fileUtils.uploadCsv(any(), eq(DAC2016_LaborCostInfoCsvImportCsvDto.class), anyBoolean(),
        anyBoolean())).thenReturn(testCase.uploadedCsvDtoList());

    ScenarioRow scenario = testCase.scenario();
    DAC2016_LaborCostInfoCsvImportUploadedFileDto dto = testCase.uploadedFileDto();
    if (dto.getTenpuFile1() != null) {
      overrideFileSize(dto.getTenpuFile1(), scenario.tenpuFile1Size());
    }
    if (dto.getTenpuFile2() != null) {
      overrideFileSize(dto.getTenpuFile2(), scenario.tenpuFile2Size());
    }
    if (dto.getTenpuFile3() != null) {
      overrideFileSize(dto.getTenpuFile3(), scenario.tenpuFile3Size());
    }
  }

  /** CSVから読み込んだUploadedFileスタブのgetSize()をシナリオ指定の値に差し替える。 */
  private void overrideFileSize(Object uploadedFile, long sizeBytes) {
    // NOTE: UploadedFileはMockitoスパイ化されたスタブである前提。実プロジェクトの
    // DtoTestUtil実装に応じて、ここは setPrivateField(uploadedFile, "size", sizeBytes) 等に
    // 置き換える必要がある可能性がある（要環境確認）。
    setPrivateField(uploadedFile, "size", sizeBytes);
  }

  /** 給与個所／業種／所属マスタの戻り値をシナリオ通りに設定する。 */
  private void arrangeMasterData(ScenarioRow scenario) {
    when(masterDataUtil.getCodeJoho(eq(DAA_AccountCdCns.JINJI_KYUYO_KASHO), any(), any()))
        .thenReturn(scenario.isKyuyoKashoFound() ? mock(DAA_CodeJohoDto.class) : null);
    when(masterDataUtil.getGyoshuJoho(any(), any()))
        .thenReturn(scenario.isGyoshuFound() ? mock(DAA_GyoshuJohoDto.class) : null);
    when(masterDataUtil.getSoshikiJoho(any(), any()))
        .thenReturn(scenario.isShozokuFound() ? mock(DAA_SoshikiJohoDto.class) : null);
    when(masterDataUtil.getSoshikiGyoshuJoho(any(), any(), any()))
        .thenReturn(scenario.isGyoshuKumiawaseFound() ? mock(DAA_SoshikiGyoshuJohoDto.class) : null);
  }

  /** 人件費連動情報明細・ヘッダRepositoryの戻り値をシナリオ通りに設定する。 */
  private void arrangeRepositories(ScenarioRow scenario) {
    List<DAA301_JinkenhiRendoJohoMeisaiRpo.RecordEntity> meisaiList;
    if ("NULL".equals(scenario.getMeisaiListState())) {
      meisaiList = null;
    } else if ("EMPTY".equals(scenario.getMeisaiListState())) {
      meisaiList = new ArrayList<>();
    } else {
      meisaiList = new ArrayList<>();
      meisaiList.add(mock(DAA301_JinkenhiRendoJohoMeisaiRpo.RecordEntity.class));
    }
    when(jinkenhiRendoJohoMeisaiRpo.where(any())).thenReturn(
        mock(jp.or.hokuren.aza.database.repository.sql.where.AZA_Where.class,
            org.mockito.Mockito.RETURNS_SELF));
    when(jinkenhiRendoJohoMeisaiRpo.select(any())).thenReturn(meisaiList);

    String headerState = scenario.getHeaderState();
    if ("NULL".equals(headerState)) {
      when(jinkenhiRendoJohoHeaderRpo.find(any(), any(), any())).thenReturn(null);
      return;
    }
    DAA301_JinkenhiRendoJohoHeaderRpo.RecordEntity headerRecord =
        mock(DAA301_JinkenhiRendoJohoHeaderRpo.RecordEntity.class);
    String shoninJokyoKbn = switch (headerState) {
      case "MISHUSEI" -> DAA_AccountCdCns.NBCD_SHONIN_JOKYO_MISHUSEI;
      case "SASHIMODOSHI" -> DAA_AccountCdCns.NBCD_SHONIN_JOKYO_SASIMODOSI;
      case "SHITAGAKI" -> DAA_AccountCdCns.NBCD_SHONIN_JOKYO_SITAGAKIHOZON;
      default -> "OTHER";
    };
    when(headerRecord.getShoninJokyoKbn()).thenReturn(shoninJokyoKbn);
    when(jinkenhiRendoJohoHeaderRpo.find(any(), any(), any())).thenReturn(headerRecord);
  }
}
